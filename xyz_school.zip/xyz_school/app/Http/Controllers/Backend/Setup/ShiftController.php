<?php

namespace App\Http\Controllers\Backend\Setup;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\model\StudentClass;
use App\model\Year;
use App\model\StudentShift;
use DB;

class ShiftController extends Controller
{
    public function view(){
    	//dd('ok');
    	$data['allData']=StudentShift::all();
    	return view('backend.setup.shift.view-shift',$data);
    }
    public function add(){
    	//dd('ok');
    	return view('backend.setup.shift.add-shift');
    }
    public function store(Request $request){
        $this->validate($request, [
            'name'=>'required',
            'name'=>'required|unique:student_shifts,name'
        ]);
    	$data = new StudentShift();
    	$data->name=$request->name;
    	$data->save();
    	return redirect()->route('setups.student.shift.view')->with('success','Data added successfully');

    }
    public function edit($id){
        $editData=StudentShift::find($id);
        return view('backend.setup.shift.add-shift',compact('editData'));
    }
    public function update(Request $request,$id){
        $data = StudentShift::find($id);
        $this->validate($request, [
            'name'=>'required',
            'name'=>'required|unique:student_shifts,name,'.$data->id
        ]);
        $data->name=$request->name;
        $data->save();
        return redirect()->route('setups.student.shift.view')->with('success','Data updated successfully');

    }
    public function delete($id){
        $data=StudentClass::find($id);
        $data->delete();
        return redirect()->route('setups.student.class.view')->with('success','Data deleted successfully');
    }
}
